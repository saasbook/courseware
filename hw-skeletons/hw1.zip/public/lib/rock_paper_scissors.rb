class RockPaperScissors

  # Exceptions this class can raise:
  class NoSuchStrategyError < StandardError ; end

  def self.winner(player1, player2)
    # YOUR CODE HERE
  end

  def self.tournament_winner(tournament)
    # YOUR CODE HERE
  end

end
